#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"

#define stdin 0
#define stdout 1
#define stderr 2

char* fmtname(char* path)
{
    char* p;
    for(p = path + strlen(path); p >= path && *p != '/'; p--)
        ;
    return p + 1;
}

void find(char* path, const char* filename)
{
    char buf[512], *p;
    int fd;
    struct dirent de;
    struct stat st;

    if((fd = open(path, O_RDONLY)) < 0)   //open path file describerS
    {
        fprintf(stderr, "find: cannot open %s\n", path);
        return;
    }
    if(fstat(fd, &st) < 0)
    {
        fprintf(stderr, "find: cannot stat %s\n", path);
        close(fd);
        return;
    }

    switch(st.type)
    {
        case T_FILE:      //FILE type, print directly
            if(strcmp(filename, fmtname(path)) == 0)
            {
                printf("%s\n", path);
            }
            break;
        case T_DIR:       //DIR type, size too long?
            if(strlen(path) + 1 + DIRSIZ + 1 > sizeof(buf))
            {
                printf("find: path too long\n");
                return;
            }
            strcpy(buf, path);     //copy path to buf
            p = buf + strlen(buf); //move pointer
            *p++ = '/'; //equal to *(p++)

            while(read(fd, &de, sizeof(de)) == sizeof(de))
            {
                if(de.inum == 0 || strcmp(de.name, ".") == 0 || strcmp(de.name, "..") == 0)
                {
                    continue;
                }
                memmove(p, de.name, DIRSIZ);
                p[DIRSIZ] = 0;
                if(stat(buf, &st) < 0)
                {
                    printf("find: cannot stat %s\n", buf);
                    continue;
                }

                find(buf, filename);
            }
            break;
    }
    close(fd);
}

int main(int argc, char* argv[])
{
    if(argc < 3)
    {
        printf("usage: find path filename\n");
    }

    for(int i = 2; i < argc; i++)
    {
        find(argv[1], argv[i]);
    }

    exit(0);
}