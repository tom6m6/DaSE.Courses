#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void child(int parent_fd[])
{
    close(parent_fd[1]);
    int i;
    if(read(parent_fd[0], &i, sizeof(i)) == 0)
    {
        //no numbers left, close pipe and exit
        close(parent_fd[0]);
        exit(0);
    }
    printf("prime %d\n", i);
    int num = 0;
    //child to grandchild
    int child_fd[2];
    pipe(child_fd);
    int pid;
    //grandchild progress
    if((pid = fork()) == 0)
    {
        child(child_fd);
    }
    //child progress
    else
    {
        close(child_fd[0]);
        while(read(parent_fd[0], &num, sizeof(num)) > 0)
        {
            //write condition
            if(num % i != 0)
            {
                write(child_fd[1], &num, sizeof(num));
            }
        }
        close(child_fd[1]);
        wait(0);
    }
    exit(0);
}

int main(int argc, char *argv[])
{
    int parent_fd[2];
    pipe(parent_fd);
    int pid;
    //child progress
    if((pid = fork()) == 0)
    {
        child(parent_fd);
    }
    //parent progress
    else
    {
        close(parent_fd[0]);
        for(int i = 2; i <= 35; i++)
        {
            write(parent_fd[1], &i, sizeof(i));
        }
        close(parent_fd[1]);
        //wait for child progress
        wait(0);
    }
    //parent progress end
    exit(0);
}