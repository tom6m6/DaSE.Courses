#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
    int pid;
    int parent_fd[2];  //parent to child
    int child_fd[2];   //child to parent
    
    //create pipe
    pipe(child_fd);
    pipe(parent_fd);

    pid = fork();   //fork
    //Child Progress
    if(pid == 0)
    {
        close(parent_fd[1]);
        close(child_fd[0]);

        char buf[16];
        //child receive ping, print
        if(read(parent_fd[0], buf, sizeof(buf)) == 1)
        {
            printf("%d: received ping\n", pid);
        }
        //child to parent
        write(child_fd[1], "pong", 1);
        exit(0);
    }

    //Parent Progress
    else
    {
        close(parent_fd[0]);
        close(child_fd[1]);
        write(parent_fd[1], "ping", 1);
        char buf[16];
        if(read(child_fd[0], buf, sizeof(buf)) == 1)
        {
            printf("%d: received pong\n", pid);
        }
    }
    exit(0);
} 