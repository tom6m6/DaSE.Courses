// Buffer cache.
//
// The buffer cache is a linked list of buf structures holding
// cached copies of disk block contents.  Caching disk blocks
// in memory reduces the number of disk reads and also provides
// a synchronization point for disk blocks used by multiple processes.
//
// Interface:
// * To get a buffer for a particular disk block, call bread.
// * After changing buffer data, call bwrite to write it to disk.
// * When done with the buffer, call brelse.
// * Do not use the buffer after calling brelse.
// * Only one process at a time can use a buffer,
//     so do not keep them longer than necessary.


#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "riscv.h"
#include "defs.h"
#include "fs.h"
#include "buf.h"

#define BUCKETSIZE 13 // number of hashing buckets
#define BUFFERSIZE 5 // number of available buckets per bucket

extern uint ticks;//引入时间戳
//  struct {
//    struct spinlock lock;
//    struct buf buf[BUFFERSIZE];  //缓冲区数组
//
    // Linked list of all buffers, through prev/next.
    // Sorted by how recently the buffer was used.
    // head.next is most recent, head.prev is least.
//    struct buf head;  //双向链表的头节点
//  } bcache;

//修改结构体bcache为bcachebucket
struct {
  struct spinlock lock;
  struct buf buf[BUFFERSIZE];
} bcachebucket[BUCKETSIZE];    //13个桶5个buffer

/*
//每个桶一个自旋锁，每个缓冲区一个睡眠锁
void
binit(void)   //对缓冲区的初始化操作，创建一个循环链表管理缓冲区
{
  struct buf *b;  //buffer指针

  initlock(&bcache.lock, "bcache");   //给整个缓冲区初始化一个自旋锁

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
  bcache.head.next = &bcache.head;    //初始化双向链表
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    b->next = bcache.head.next;
    b->prev = &bcache.head;
    initsleeplock(&b->lock, "buffer");  //对每个buffer块加睡眠锁
    bcache.head.next->prev = b;
    bcache.head.next = b;    //头插法
  }
}
*/
void
binit(void)
{
  for(int i=0; i<BUCKETSIZE; i++){
    initlock(&bcachebucket[i].lock, "bcachebucket");  //对每个桶初始化自旋锁
    for(int j=0; j<BUFFERSIZE; j++){
      initsleeplock(&bcachebucket[i].buf[j].lock, "buffer");  //对桶的buffer初始化睡眠锁
    }
  }
}

/*
// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
static struct buf*
bget(uint dev, uint blockno)
{
  struct buf *b;

  acquire(&bcache.lock);  //申请bcache全局锁

  // Is the block already cached?  //搜索双向循环链表
  for(b = bcache.head.next; b != &bcache.head; b = b->next){  //从头到尾遍历
    if(b->dev == dev && b->blockno == blockno){  //设备号和块号符合
      b->refcnt++;
      release(&bcache.lock);  //释放对缓冲区的大锁
      acquiresleep(&b->lock);  //对找到的buffer加睡眠锁
      return b;
    }
  }

  // Not cached.  //缓冲未命中
  // Recycle the least recently used (LRU) unused buffer.  //LRU返回空闲块
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){   //从尾到头遍历
    if(b->refcnt == 0) {  //计数为0,没有进程使用的空闲块
      b->dev = dev;
      b->blockno = blockno;
      b->valid = 0;
      b->refcnt = 1;  
      release(&bcache.lock);  //释放大锁
      acquiresleep(&b->lock);  //加睡眠锁
      return b;
    }
  }
  panic("bget: no buffers");
}
*/

int hash(uint blockno)
{
  return blockno%BUCKETSIZE;
}


static struct buf*
bget(uint dev, uint blockno)
{
  struct buf *b;
  //申请桶的锁
  int bucket = hash(blockno);
  acquire(&bcachebucket[bucket].lock); //

  for(int i=0; i<BUFFERSIZE; i++){
    b = &bcachebucket[bucket].buf[i];
    if(b->dev ==dev && b->blockno == blockno){
      b->refcnt++;  //引用计数
      b->lastuse = ticks;  //最近使用时间
      release(&bcachebucket[bucket].lock); 
      acquiresleep(&b->lock);
      return b;
    }
  }

  //遍历查找该桶最近最少使用的空闲buffer(ticks较小)
  uint flag = 0xffffffff; //最大的unsigned int
  int least_idx = -1;
  for(int i=0; i<BUFFERSIZE; i++){
    b = &bcachebucket[bucket].buf[i];
    if(b->refcnt == 0 && b->lastuse < flag){
      flag = b->lastuse;
      least_idx = i;
    }
  }
  if(least_idx == -1){
    panic("bget: no unused buffer for recycle");
  }
  //重新分配新的dev，blockno
  b = &bcachebucket[bucket].buf[least_idx];
  b->dev = dev;
  b->blockno = blockno;
  b->lastuse = ticks;
  b->valid = 0;
  b->refcnt = 1;
  release(&bcachebucket[bucket].lock);
  acquiresleep(&b->lock);

  return b;
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
  struct buf *b;

  b = bget(dev, blockno);  //设备号和块号
  //未命中，则先从磁盘中读取内存
  if(!b->valid) {
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}

//将缓冲内容写入磁盘，必须持有这块的睡眠锁
// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
  if(!holdingsleep(&b->lock))  //是否持有睡眠锁
    panic("bwrite");
  virtio_disk_rw(b, 1);
}

// Release a locked buffer. //释放一个缓冲，必须持有该缓冲的睡眠锁
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
  if(!holdingsleep(&b->lock))  //是否持有缓冲区的睡眠锁
    panic("brelse");
  int bucket = hash(b->blockno);
  releasesleep(&b->lock);  //释放buffer的睡眠锁

  acquire(&bcachebucket[bucket].lock);  //对bcache加自旋锁
  b->refcnt--;
  //删除该缓冲区b，将b加入到LRU的bcache中
  /*
  if (b->refcnt == 0) {
    // no one is waiting for it.  
    b->next->prev = b->prev;  //先把b从链表中删除，更新缓冲区的指针
    b->prev->next = b->next;
    b->next = bcache.head.next; //将b插入到链表头部
    b->prev = &bcache.head;
    bcache.head.next->prev = b;
    bcache.head.next = b;
  }
  */
  release(&bcachebucket[bucket].lock);
}
/*
void
bpin(struct buf *b) {
  acquire(&bcache.lock);
  b->refcnt++;
  release(&bcache.lock);
}
*/

void
bpin(struct buf *b){
  int bucket = hash(b->blockno);  //哈希寻找桶
  acquire(&bcachebucket[bucket].lock);
  b->refcnt++;
  release(&bcachebucket[bucket].lock);
}

/*
void
bunpin(struct buf *b) {
  acquire(&bcache.lock);
  b->refcnt--;
  release(&bcache.lock);
}*/

void 
bunpin(struct buf *b){
  int bucket = hash(b->blockno);  //哈希寻找桶
  acquire(&bcachebucket[bucket].lock);
  b->refcnt--;
  release(&bcachebucket[bucket].lock);
}

